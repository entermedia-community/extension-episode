# Copyright(c) 2008 Telestream.
# Radmansgatan 49, SE-113 60, Stockholm, Sweden
# All Rights Reserved.
# 
# This software is the confidential and proprietary information of 
# Telestream ("Confidential Information"). You shall not
# disclose such Confidential Information and shall use it only in
# accordance with the terms of the license agreement you entered into
# with Telestream.

# Author: Niklas Lundborg <niklasl@telestream.se>

require 'xmlrpc/client'
require "EngineAPIWrapper"
require 'pp'
require 'English'    
    
def test(test, message)
  if not test
    raise "#{message}"
  end
end

server = XMLRPC::Client.new2("http://localhost:40406")

group_path = "/Templates/By Format/DV/PAL"
setting_path = "#{group_path}/DV25_PAL.setting"

# test getDepots
begin
  call = "engine.getDepots"
  puts "[#{call}]"
  response = server.call(call)
  test(response.class == Array, "#{call} result != array")
  test(response.size > 0, "#{call} is empty")
  response.each { |item| test(item.mountURLs.reject { |value| value =~ /^nfs:/i }.empty?, "#{call} #{item} has no nfs url") }
  puts "passed test"
rescue
  puts "#{$ERROR_INFO}"
end
puts


# test getSettings
begin
  call = "engine.getSettings"
  puts "[#{call}]"
  response = server.call(call)
  test(response.class == Array, "#{call} result != array")
  test(response.size > 0, "#{call} is empty")
  test(response[0].is_group, "#{call}, first item is not a group")
  puts "passed test"
rescue
  puts "#{$ERROR_INFO}"
end
puts


# - (NSArray*)getSettingsInGroup:(id<SettingNode>)group; 
# def getSettingsInGroup(group)
# begin
#   call = "engine.getSettingsInGroup"
#   puts "[#{call}]"
#   args = response[0]
#   response = server.call(call, args)
#   test(response.class == Array, "#{call} #{args} result != array")
#   puts "passed test"
# rescue
#   puts "#{$ERROR_INFO}"
# end
# puts


# #- (NSArray*)getSettingsInGroupAtPath:(NSString*)path; 
# def getSettingsInGroupAtPath(path)
begin
  call = "engine.getSettingsInGroupAtPath"
  puts "[#{call}]"
  args = "/"
  response = server.call(call, args)
  test(response.class == Array, "#{call} #{args} result != array")
  puts "passed test"
rescue
  puts "#{$ERROR_INFO}"
end
puts


# # - (id<SettingData>)getSettingDataAtPath:(NSString*)path;
# def getSettingDataAtPath(path)
begin
  call = "engine.getSettingDataAtPath"
  args = setting_path
  puts "[#{call}] #{args}"
  response = server.call(call, args)
  test(response.class == Episode::API::SettingData, "#{call} #{args} result != SettingData")
  test(response.xml_string.length > 0, "#{call} #{args} result.xml_string.length <= 0")
  puts "passed test"
rescue
  puts "#{$ERROR_INFO}"
end
puts


# # - (id<SettingData>)getSettingDataForSetting:(id<SettingNode>)pattern;
# def getSettingDataForSetting(pattern)
begin
  response = server.call("engine.getSettingNodeAtPath", setting_path)
  if (response)
    call = "engine.getSettingDataForSetting"
    puts "[#{call}]"
    args = response
    response = server.call(call, args)
    test(response.class == Episode::API::SettingData, "#{call} #{args} result != SettingData")
    test(response.xml_string.length > 0, "#{call} #{args} result.xml_string.length <= 0")
    puts "passed test"
  end
rescue
  puts "#{$ERROR_INFO}"
end
puts


# # - (id<SettingNode>)getSettingNodeForPath:(NSString*)path; 
# def getSettingNodeForPath(path)
begin
  call = "engine.getSettingNodeAtPath"
  args = setting_path
  puts "[#{call}] #{args}"
  response = server.call(call, args)
  test(response.class == Episode::API::SettingNode, "#{call} #{args} result != setting")
  # test(response.length > 0, "#{call} #{args} result.length <= 0")
  puts "passed test"
rescue
  puts "#{$ERROR_INFO}"
end
puts


# # - (OperationResult)newSettingGroupWithName:(NSString*)name inGroup:(NSString*)groupPath;
# def newSettingGroupWithNameInGroup(name, groupPath)
begin
  call = "engine.newSettingsGroup"
  args = ["APITest", "/"]
  puts "[#{call}] #{args.join(', ')}"
  response = server.call(call, "APITest", "/")
  test(response == OperationOk, "#{call} #{args} result != ok")
  puts "passed test"
rescue
  puts "#{$ERROR_INFO}"
end
puts


# # - (OperationResult)newSettingWithName:(NSString*)name
# #                           patternData:(id<SettingData>)data
# #                               inGroup:(NSString*)groupPath;
# def newSettingWithNameSettingDataInGroup(name, data, groupPath)
begin
  pd = server.call("engine.getSettingDataAtPath", setting_path)

  call = "engine.newSettingWithNameSettingDataInGroup"
  args = ["test1", pd, "/APITest"]
  puts "[#{call}] #{args.join(', ')}"
  response = server.call(call, "test1", pd, "/APITest")
  test(response == OperationOk, "#{call} #{args} result != ok")
  puts "passed test"
rescue
  puts "#{$ERROR_INFO}"
  raise $!  
end
puts


# # - (OperationResult)deleteSettingAtPath:(NSString*)path;
# def deleteSettingAtPath(path)
begin
  call = "engine.deleteSettingAtPath"
  args = "/APITest/test1.setting"
  puts "[#{call}] #{args}"
  response = server.call(call, args)
  test(response == OperationOk, "#{call} #{args} result != ok")
  puts "passed test"
rescue
  puts "#{$ERROR_INFO}"
end
puts


# # - (OperationResult)deleteSettingGroupAtPath:(NSString*)path;
# def deleteSettingGroupAtPath(path)
begin
  call = "engine.deleteSettingGroupAtPath"
  args = "/APITest"
  puts "[#{call}] #{args}"
  response = server.call(call, args)
  test(response == OperationOk, "#{call} #{args} result != ok")
  puts "passed test"
rescue
  puts "#{$ERROR_INFO}"
end
puts

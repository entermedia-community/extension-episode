# Copyright(c) 2008 Telestream.
# Radmansgatan 49, SE-113 60, Stockholm, Sweden
# All Rights Reserved.
# 
# This software is the confidential and proprietary information of 
# Telestream ("Confidential Information"). You shall not
# disclose such Confidential Information and shall use it only in
# accordance with the terms of the license agreement you entered into
# with Telestream.

# Author: Niklas Lundborg <niklasl@telestream.se>

require 'EpisodeEngineAPI'
require 'osx/cocoa'
require 'pp'

include OSX

require_framework "EpisodeEngine"

module Episode
  module API
    class Engine < EngineBase
      attr_accessor :marshallable
      attr_accessor :dynamic_method_lookup
      attr_accessor :delegate
      attr_reader :connected
      attr_reader :engine_ctrl
      
      def initialize(options = Episode::API::Options.default)
        super(options)
        @marshallable = true
        @dynamic_method_lookup = false
        @delegate = nil
        @connected = false
        @engine_ctrl = Create.engineCtrlWithTimeout(2.0)
        @engine_ctrl.setDelegate(self)
      end
      
      # Connect to an Engine
      # returns @connected
      def connect(host = @options.host, password = @options.password, client_id = @options.client_id, port = @options.port)
        p "connect #{host} #{password}"
        sp = NSSocketPort.alloc.initRemoteWithTCPPort_host(40402, host)
        res = @engine_ctrl.connect_username_password_clientName_clientIcon(sp, "anonymous", password, client_id, nil)
        log "Could not connect to #{@options.host}. Result: #{res}" if res != ConnectionOk
        @connected = res == ConnectionOk
      end

      # Disconnect from Engine
      def disconnect
        log "@engine_ctrl.delegate: #{@engine_ctrl.delegate}"
        @engine_ctrl.disconnect
        log @engine_ctrl.lastError
      end

      # Check connection status
      def connected?
        @engine_ctrl.isConnected
      end
      
      # return last error message
      # - (NSString*)lastError;
      def lastError
        @engine_ctrl.lastError().to_s
      end
      
      # Returns an array of id<Depot>.
      # - (NSArray*)getDepots;
      def getDepots
        depots = @engine_ctrl.getDepots().to_a
        depots.collect! { |d| Episode::API::Depot.new(d) }
      end

      # Returns an array of id<PatterNode> from root.
      # - (NSArray*)getPatterns;
      def getSettings
        patterns = @engine_ctrl.getPatterns().to_a
        if @marshallable
          patterns.collect! { |p| Episode::API::SettingNode.new(p) }
        else
          patterns.collect! { |p| Episode::API::SettingNode.new(p, self) }
        end
        patterns
      end
      
      # // Returns an array of id<PatterNode> from group.
      # - (NSArray*)getPatternsInGroup:(id<PatternNode>)group; 
      def getSettingsInGroup(group = nil)
        if (group == nil)
          return getSettings()
        end
        
        if group.is_group
          patterns = @engine_ctrl.getPatternsInGroupAtPath(group.path).to_a
          if @marshallable
            patterns.collect! { |p| Episode::API::SettingNode.new(p) }
          else
            patterns.collect! { |p| Episode::API::SettingNode.new(p, self) }
          end
        else
          return nil
        end
      end

      # // Returns an array of id<PatterNode> from group.
      # - (NSArray*)getPatternsInGroupAtPath:(NSString*)path; 
      def getSettingsInGroupAtPath(path)
        path = "/" if !path || path == ""
        patterns = @engine_ctrl.getPatternsInGroupAtPath(path).to_a
        if @marshallable
          patterns.collect! { |p| Episode::API::SettingNode.new(p) }
        else
          patterns.collect! { |p| Episode::API::SettingNode.new(p, self) }
        end
      end
      
      # // Returns the pattern data or nil.
      # - (id<PatternData>)getPatternDataAtPath:(NSString*)path;
      def getSettingDataAtPath(path)
        data = @engine_ctrl.getPatternDataAtPath(path)
        return nil if ! data
        SettingData.new(data)
      end
      
      # // Returns the pattern data or nil.
      # - (id<PatternData>)getPatternDataForPattern:(id<PatternNode>)pattern;
      def getSettingDataForSetting(setting)
        getSettingDataAtPath(setting.path)
      end

      # // Returns the pattern node or nil if path does not exist.
      # - (id<PatternNode>)getPatternNodeForPath:(NSString*)path; 
      def getSettingNodeAtPath(path)
        p = @engine_ctrl.getPatternNodeForPath(path)
        if (p)
          if @marshallable
            Episode::API::SettingNode.new(p)
          else
            Episode::API::SettingNode.new(p, self)
          end
        else
          raise "could not get node for path: #{path}"
        end
      end
      
      # // Returns whether the operation was ok with engine.
      # - (OperationResult)newPatternGroupWithName:(NSString*)name inGroup:(NSString*)groupPath;
      def newSettingsGroup(newName, groupPath)
        @engine_ctrl.newPatternGroupWithName_inGroup(newName, groupPath)
      end
      
      # // Returns whether the operation was ok with engine.
      # - (OperationResult)newPatternWithName:(NSString*)name
      #                           patternData:(id<PatternData>)data
      #                               inGroup:(NSString*)groupPath;
      def newSetting(name, data, groupPath)
        @engine_ctrl.newPatternWithName_patternData_inGroup(name, data.to_ns, groupPath)
      end

      # // Returns whether the operation was ok with engine.
      # - (OperationResult)deletePatternGroupAtPath:(NSString*)path;
      def deleteSettingsGroup(path)
        @engine_ctrl.deletePatternGroupAtPath(path)
      end
      
      # // Returns whether the operation was ok with engine.
      # - (OperationResult)deletePatternAtPath:(NSString*)path;
      def deleteSettingAtPath(path)
        @engine_ctrl.deletePatternAtPath(path)
      end

      # Returns a list of jobs
      # - (NSArray)getJobs:(BOOL)includeArchive;
      def getJobs(includeArchive = false)
        jobs = @engine_ctrl.getJobs(includeArchive).to_a
        jobs.collect! { |j| Episode::API::Job.new(j) }
        jobs
      end
      
      # - (id<Job>)getJobForID:(JobID)jobID;
      def getJobForID(id)
        Episode::API::Job.new(@engine_ctrl.getJobForID(id))
      end
      
      # // Returns a job identifier which can be used to retrieve status for the job.
      # // Check return (return-value < JobID_ErrorThreshold) == OK else ERROR
      # // When no priority is specified, PWEngineProxy_NormalJobPriority is used
      # 
      # - (JobID)submitJob:(NSString*)url patternPath:(NSString*)path subscribeStatus:(BOOL)sub;
      # - (JobID)submitJob:(NSString*)url patternPath:(NSString*)path prio:(UInt16)prio subscribeStatus:(BOOL)sub;
      # - (JobID)submitJob:(NSString*)url patternPath:(NSString*)path prio:(UInt16)prio metaData:(NSDictionary*)metaData subscribeStatus:(BOOL)sub;
      # - (JobID)submitJob:(NSString*)url
      #        patternPath:(NSString*)path
      #               prio:(UInt16)prio
      #           metaData:(NSDictionary*)metaData
      #               name:(NSString*)name
      #    subscribeStatus:(BOOL)sub;
      
      #def submitJob_patternPath_prio_metaData_name_subscribeStatus(url, path, prio, name = "[api job]", meta = {}, sub = false)
      def submitJob(media_url, path, prio, name = "[api job]", meta = {}, sub = false)
        @engine_ctrl.submitJob_patternPath_prio_metaData_name_subscribeStatus(media_url, path, prio, meta, name, sub)
      end
      
      # - (JobID)submitJobWithPatternData:(id<PatternData>)patternData subscribeStatus:(BOOL)sub;
      # - (JobID)submitJobWithPatternData:(id<PatternData>)patternData prio:(UInt16)prio subscribeStatus:(BOOL)sub;
      # - (JobID)submitJobWithPatternData:(id<PatternData>)patternData prio:(UInt16)prio metaData:(NSDictionary*)metaData subscribeStatus:(BOOL)sub;
      # - (JobID)submitJobWithPatternData:(id<PatternData>)patternData
      #                              prio:(UInt16)prio
      #                          metaData:(NSDictionary*)metaData
      #                              name:(NSString*)name
      #                   subscribeStatus:(BOOL)sub;
      
      #def submitJobWithPatternData_prio_metaData_name_subscribeStatus(data, prio, name = "[api job]", meta = {}, sub = false)
      def submitJobWithSettingData(data, prio, name = "[api job]", meta = {}, sub = false)
        @engine_ctrl.submitJob_patternPath_prio_metaData_name_subscribeStatus(data, prio, meta, name, sub)
      end
             
      # // Returns an array of id<Job>
      # - (NSArray*)getJobs:(BOOL)aIncloudeArchive;
      # 
      # # Asynchronous methods
      # 
      # - (void)cancelJobWithID:(JobID)jobID;
      def cancelJobWithID(id)
        @engine_ctrl.cancelJobWithID(id)
      end
      
      # - (void)abortJobWithID:(JobID)jobID;
      def abortJobWithID(id)
        @engine_ctrl.abortJobWithID(id)
      end
      
      # - (void)setPriority:(UInt16)prio forJobWithID:(JobID)jobID;
      def setPriorityForJobWithID(prio, id)
        @engine_ctrl.setPriority_forJobWithID(prio, id)
      end

      def method_missing(sym, *args)
        if @dynamic_method_lookup
          log "dynamic_method_lookup"
          if @engine_ctrl.respondsToSelector(sym.to_s)
            log "@engine_ctrl.respondsToSelector #{sym}"
            result = @engine_ctrl.send(sym, *args)
          elsif @engine_ctrl.respondsToSelector(sym.to_s + ":")
            log "@engine_ctrl.respondsToSelector #{sym}:"
            result = @engine_ctrl.send(sym, *args)
          else
            s = sym.to_s.gsub(/_([a-z])/) { |s| $1.upcase } # example: my_method -> myMethod
            if @engine_ctrl.respondsToSelector(s)
              log "@engine_ctrl.respondsToSelector #{sym}"
              result = @engine_ctrl.send(s, *args)            
            elsif @engine_ctrl.respondsToSelector(s + ":")
              log "@engine_ctrl.respondsToSelector #{s}:"
              result = @engine_ctrl.send(s, *args)
            end
          end
        end
        log "undefined method '#{sym}' for #{@engine_ctrl}"
      end

      # delegate methods
      # - (void)enginectrl:(id<EngineCtrl>)ctrl connectionLost:(ConnectionResult)reason
      def enginectrl_connectionLost(ctrl, reason)
        log("connection lost: %p %d", ctrl, reason)
        @connected = false
        if (@delegate and @delegate.responds_to?(:engine_connection_lost))
          @delegate.engine_connection_lost(ctrl, reason)
        end
      end 

      # - (void)enginectrl:(id<EngineCtrl>)ctrl jobSubscription:(UInt32)jobID
      #                                                newState:(State)state
      #                                                  reason:(Reason)reason;
      def enginectrl_jobSubscription_newState_reason(ctrl, job_id, state, reason)
        log("job #{job_id}, new state: #{state}, reason: #{reason}")
      end

      # - (void)enginectrl:(id<EngineCtrl>)ctrl jobSubscription:(UInt32)jobID
      #                                                progress:(UInt32)progress;
      def enginectrl_jobSubscription_progress(ctrl, job_id, progress)
        log("job: #{job_id}, progress: #{progress}")
      end
    end
  end
end

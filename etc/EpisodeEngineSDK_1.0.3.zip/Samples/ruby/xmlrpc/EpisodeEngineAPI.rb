# Copyright(c) 2008 Telestream.
# Radmansgatan 49, SE-113 60, Stockholm, Sweden.
#
# All Rights Reserved.
# 
# This software is the confidential and proprietary information of 
# Telestream ("Confidential Information"). You shall not
# disclose such Confidential Information and shall use it only in
# accordance with the terms of the license agreement you entered into
# with Telestream.

# Author: Niklas Lundborg <niklasl@telestream.se>

require 'xmlrpc/marshal'

module Kernel #:nodoc:
  private
  def this_method
    caller[0] =~ /`([^']*)'/ and $1
  end
end

class Object #:nodoc:
  # Print a message, formatted with date, time, class name, and method name.
  # Example output: 2008-02-20 22:32:04 [ClassName#MethodName] Message Argument
  def log(message = "", *args)
    printf("#{DateTime.now.strftime("%F %T")} [#{String(self.class)}##{caller[0] =~ /`([^']*)'/ and $1}] " + message + "\n", *args)
  end
end

module Episode
  module API

    ENGINE_RUBY_API_VERSION = '1.0'

    #
    # Class representing an Engine Depot
    #
    class Depot
      include XMLRPC::Marshallable

      #--
      # - (NSString*)name;
      # - (NSString*)engineMountPoint;
      # - (NSString*)subDir;
      # - (NSArray*)mountURLs;
      # - (BOOL)isReadOnly;
      #++

      # Descriptive name of the Depot. Example: "Default"
      attr_accessor :name
      # The local mount point used by Engine for this Depot. Example: "/Users/Shared/Epiosde Engine/Depot."
      attr_accessor :engineMountPoint
      # The sub directory of the engineMountPoint and the mountURLs where the Depot resides. Example: "Depot"
      attr_accessor :subDir
      # An array of URLS you can use to access the Depot.
      attr_accessor :mountURLs
      # Indicates if this is a read only Depot. Currently not used. Included for future releases.
      attr_accessor :isReadOnly

      # Argument depot shall be a class of type OSX::PWDepot
      def initialize(depot = nil)
        if depot
          @name = depot.name.to_s
          @engineMountPoint = depot.engineMountPoint.to_s
          @subDir = depot.subDir.to_s
          @mountURLs = depot.mountURLs.to_a.collect! { |x| x.to_s }
          @isReadOnly = depot.isReadOnly
        end
      end
    end

    #
    # Class representing Job status
    #
    class Status
      include XMLRPC::Marshallable

      #--
      # - (State)state;
      # - (UInt32)time;
      # - (UInt32)progress;     // [0..100]
      # - (Reason)reason;
      # - (NSString*)reasonString;
      #
      # typedef enum
      # {
      #     Created,
      #     Queued,
      #     Running,
      #     Stopped,
      #     Finished,
      #     Failed,
      # } State;
      # 
      # // These reasons are used for Stopped, Finished and Failed states
      # typedef enum
      # {
      #     Unspecified,
      #     NoStart,
      #     BadCom,
      #     BadJob,
      #     Fail,
      #     Crash,
      #     Lost,
      #     Cancel,
      #     Abort,
      #     Finish
      # } Reason;
      #++

      # Integer. State of current job.
      #
      # Use stateString to get a string representation of the state.
      #
      # 0 = Created
      # 1 = Queued
      # 2 = Running
      # 3 = Stopped
      # 4 = Finished
      # 5 = Failed
      attr_accessor :state

      # Time of this status.
      attr_accessor :time

      # Progress for jobs with state Running. Integer between 0 and 100. Represents percentual progress.
      attr_accessor :progress

      # These reasons are used for Stopped, Finished and Failed states.
      attr_accessor :reason

      # Argument status shall be an instance of OSX::Status
      def initialize(status = nil)
        if (status)
          @state = status.state
          @time = status.time
          @progress = status.progress
          @reason = status.reason
        end
      end

      # Returns a textual representation of @state
      def stateString
        case @state
        when Created
          return "Created"
        when Queued
          return "Queued"
        when Running
          return "Running"
        when Stopped
          return "Stopped"
        when Finished
          return "Finished"
        when Failed
          return "Failed"
        end
      end

      # Returns a textual representation of @reason
      def reasonString
        case @reason
        when NoStart:
          return "NotStarted"
        when BadCom:
          return "BadCommunication"
        when BadJob:
          return "BadJob"
        when Fail:
          return "Failed"
        when Crash:
          return "Crashed"
        when Lost:
          return "Lost"
        when Cancel:
          return "Cancelled"
        when Abort:
          return "Aborted"
        when Finish:
          return "Finished"
        end

        "Unspecified"
      end
    end

    #
    # Class representing an Episode Engine Job
    #
    class Job
      include XMLRPC::Marshallable

      #--
      # - (NSString*)name;
      # - (JobID)jobID;
      # - (NSArray*)history;    // Array of id<Status>
      # - (id<Status>)currentStatus;
      # - (NSDictionary*)metaData;
      #++

      # Name of the Job
      attr_accessor :name
      
      # Job id
      attr_accessor :jobID
      
      # History is an array of all the previous states the job. The states are instances of Status.
      attr_accessor :history
      
      # Contains current Status of the job. 
      attr_accessor :currentStatus
      
      # A dictionary of meta data associated with the job.
      attr_accessor :metaData

      def initialize(job = nil)
        if (job)
          @name = job.name.to_s
          @jobID = job.jobID
          @history = job.history.to_a.map! { |status| Status.new(status) }
          @currentStatus = Status.new(job.currentStatus)
          @metaData = job.metaData.to_ruby
        end
      end
    end

    #
    # Class representing an Episode Setting
    #
    class SettingNode
      include XMLRPC::Marshallable

      # Reference to an Episode::API::Engine instance
      attr_accessor :engine
      # Name of the setting. Example: "H264_Small"
      attr_accessor :name
      # Path of the setting in the shared settings tree. Example: "/Templates/By Format/H264/Download/H264_Small.setting"
      attr_accessor :path
      # True if the SettingNode represents a folder.
      attr_accessor :is_group

      def initialize(pattern = nil, engine = nil)
        if (pattern)
          @engine = engine
          @name = pattern.name.to_s
          @path = pattern.path.to_s
          @is_group = pattern.isGroup
        end
      end

      # Compares only name
      def <=>(othersetting)
        return self.name <=> othersetting.name
      end

      def children
        if (@is_group)
          if (!@children)
            @children = @engine.getSettingsInGroupAtPath(@name)
          end

          return @children
        end

        return nil
      end

      # def to_s
      #   @name
      # end
    end

    # Compatibility class
    class Setting < SettingNode #:nodoc:
    end

    #
    # Class representing raw XML Engine::API::SettingNode data
    #
    class SettingData
      include XMLRPC::Marshallable

      # The raw XML string data
      attr_accessor :xml_string

      # Argument pattern_data shall be an instance of OSX::PatternData
      def initialize(pattern_data = nil)
        if (pattern_data)
          raw_data = pattern_data.rawFormat
          string = NSString.alloc.initWithData_encoding(raw_data, NSUTF8StringEncoding)
          rstring = string.to_s
          string.release
          @xml_string = rstring
        end
      end

      # Returns an instance of OSX::PatternData
      def to_ns
        # nsxmlstring = ""
        # if @xml_string.responds_to?(to_ns)
        nsxmlstring = @xml_string.to_ns
        # else
        # nsxmlstring = @xml_string.to_nsstring
        # end
        OSX::PatternData.alloc.initWithRawFormat(nsxmlstring.dataUsingEncoding(NSUTF8StringEncoding))
      end
    end

    #
    # Base Class representing a connection to Episode Engine.
    #
    class EngineBase #:nodoc:

      attr_accessor :options

      #
      # Note: You can pass Episode::API::Options.default as options
      #
      def initialize(options = Episode::API::Options.default)
        @options = options
      end

      #
      # All states a job can be in
      # * Running
      # * Created (Not in list unless arg include_created_state is 'true')
      # * Queued
      # * Failed
      # * Stopped
      # * Finished
      #
      def self.all_job_states(include_created_state = false)
        if (include_created_state)
          ["Running", "Created", "Queued", "Failed", "Stopped", "Finished"]
        else
          ["Running", "Queued", "Failed", "Stopped", "Finished"]
        end
      end
    end

    #
    # Class for handling options for Episode::API::Engine
    #
    class Options #:nodoc:
      require 'optparse'
      require 'optparse/time'
      require 'ostruct'

      #
      # Return a structure describing the default options for Episode::API::Engine.
      #
      def self.default
        # Set default values
        options = OpenStruct.new
        options.verbose = false
        options.host = "localhost"
        options.port = 40402
        options.password = "anonymous"
        options.client_id = "RubyClient"
        options.depot = "Default"
        options.debug = false
        options.loop = 1
        options.wait_for_job = false

        # Only used by EngineCLIWrapper
        options.engine_root = "."
        options.media = []
        options.settings = []

        options
      end

      # Parse command line arguments
      def self.parse(args)
        # The options specified on the command line will be collected in *options*.
        options = Options.default

        opts = OptionParser.new do |opts|
          opts.banner = "Usage: submitter.rb [options]"

          opts.separator ""
          opts.separator "Specific options:"

          opts.on("-m", "--media <media file>", "Media file to submit") do |media|
            options.media << media
          end

          opts.on("-s", "--setting <setting-id>", "Setting to encode media with") do |setting|
            options.settings << setting
          end

          opts.on("--host <host>", "Engine host. Default is 127.0.0.1") do |host|
            options.host = host
          end

          opts.on("-p", "--port <port>", "Engine port") do |port|
            options.port = port
          end

          opts.on("--password <password>", "Engine password") do |password|
            options.password = password
          end

          opts.on("--depot <depot>", "Engine depot") do |depot|
            options.depot = depot
          end

          opts.on("-r", "--engine_root <path to engine binary>", "Engine binary path") do |v|
            options.engine_root = v
          end

          opts.separator ""
          opts.separator "Common options:"

          # Boolean switch.
          opts.on("-v", "--[no-]verbose", "Run verbosely") do |v|
            options.verbose = v
          end

          opts.on("--[no-]debug", "Debug") do |v|
            options.debug = v
          end

          opts.on("--loop <count>", Integer, "Loop") do |v|
            options.loop = v
          end

          # No argument, shows at tail.  This will print an options summary.
          # Try it and see!
          opts.on_tail("-h", "--help", "Show this message") do
            puts opts
            exit
          end

          # Another typical switch to print the version.
          opts.on_tail("--version", "Show version") do
            puts "Version #{API_VERSION}"
            exit
          end
        end

        opts.parse!(args)
        options
      end  # end parse()
    end # end class Options
  end
end

# try to automatcally load api files
# unless Episode::API::IS_LOADED
# puts "Loading API"
# begin
#     if require 'EngineAPIWrapper'
#         puts 'Using EngineAPIWrapper'
#     end
# rescue LoadError
#     begin
#         if require 'EngineCLIWrapper'
#             puts 'Using EngineCLIWrapper'
#         end
#     rescue LoadError
#         puts 'Unable to load Engine API Wrapper'
#         exit 1
#     end
# end
# end

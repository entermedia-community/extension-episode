use XMLRPC::Lite;
my $url = "http://localhost:40406/RPC2";
my $res = XMLRPC::Lite
    -> proxy($url)
#    -> on_debug(sub { print @_; })
    -> call('engine.getDepots')
    -> result();
    
my @groups = @{$res};
foreach my $group (@groups) {
    print $group;
    
    print $group->{'name'};

    foreach $k (keys (%group))
    {
      print $k;
    }
}
      
# use RPC::XML::Client;
# use Frontier::Client;
# use Data::Dumper;
# 
# # use Frontier::RPC2;
# # my $coder = Frontier::RPC2->new(use_objects => 1);
# # my $result = [ "you guessed", 42 ];
# # my $xml_string = $coder->encode_response($result);
# # print $xml_string,"\n";
# 
# # Make an object to represent the XML-RPC server.
# $server_url = 'http://127.0.0.1:40406/RPC2';
# $server = Frontier::Client->new(url => $server_url, use_objects => 1, debug => 1);
# 
# # Call the remote server and get our result.
# $result = $server->call('engine.getDepots');
# 
# print "--------------------------------------------";
# print "\n";
# print Dumper($result);
# 
# 
# my $client = RPC::XML::Client->new('http://127.0.0.1:40406/RPC2');
# my $result = $client->send_request('engine.getDepots');
# die $result unless defined($result);
# die $result->code . ': ' . $result->string if $result->is_fault;
# # print join(' ',  @{$result->value}), "\n";
# my $a = @{$result->value};

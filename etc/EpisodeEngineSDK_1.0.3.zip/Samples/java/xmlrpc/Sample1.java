/*package net.telestream.episode.engine.sdk.samples;*/

import java.net.MalformedURLException;
import java.util.Hashtable;

// Example users the redstone xml-rpc library. Available at http://xmlrpc.sourceforge.net/#downloads
import redstone.xmlrpc.*;

/**
  *
  * @author Niklas Lundborg (niklasl@telestream.se)
  * @version 1.0
  * 
  * Sample code for Episode Engine integration via XML-RPC
  */
public class Sample1 {

  String engine_xmlrpc_host = "127.0.0.1";
  int engine_xmlrpc_port = 40406;
  XmlRpcClient client = null;

  /**
    * @param args the command line arguments
    */
  public static void main(String[] args) throws Exception {
    Sample1 sample = new Sample1();

    // List depots
    sample.listDepots();
    // List some settings
    sample.listSettings();

    //Engine accepts SMB URLs
    /*String media_url = "smb://WORKGROUP;user:password@host/path/media.file";*/

    //Engine also accepts FTP URLs
    /*String media_url = "ftp://user:password@host/path/media.file";*/

    String media_url = "file:/Users/niklasl/Movies/Test/1sek_rock.mov";

    if (args.length > 0) {
      // Get media URL from command line
      media_url = args[0];
    }

    // Submit a job
    int newJobID = sample.submitJob(media_url);

    // Monitor progress
    int progress = 0;
    while ((progress = sample.getProgressForJobID(newJobID)) >= 0 && progress < 100)
    {
      System.out.println("progress: " + progress + "%");
      Thread.sleep(1000);
    }
    System.out.println("progress: " + progress + "%");
  }

  Sample1() throws MalformedURLException, XmlRpcException, XmlRpcFault {
    client = new XmlRpcClient("http://" + engine_xmlrpc_host + ":" + engine_xmlrpc_port + "/RPC2", false);
  }

  /**
    * List available Depots
    */
  public void listDepots() throws MalformedURLException, XmlRpcException, XmlRpcFault {
    System.out.println("Depots:");
    XmlRpcArray depots = (XmlRpcArray) client.invoke("engine.getDepots", new Object[]{});
    for (Object depot : depots) {
      System.out.println(depot);
    }
  }

  /**
    * Example of how to list available settings
    */
  public void listSettings() throws MalformedURLException, XmlRpcException, XmlRpcFault {
    String gpath = "/Templates/By Format/DV/PAL";
    System.out.println("Settings at path: " + gpath);
    XmlRpcArray settings = (XmlRpcArray) client.invoke("engine.getSettingsInGroupAtPath", new Object[]{gpath});
    System.out.println(gpath);
    for (Object setting : settings) {
      System.out.println("    " + ((XmlRpcStruct)setting).getString("name"));
    }
  }

  /**
    * Example of how to submit a job to Engine
    */
  public int submitJob(String media_url) throws MalformedURLException, XmlRpcException, XmlRpcFault {
    System.out.println("Submitting a job...");
    String setting_path = "/Templates/By Format/DV/PAL/DV25_PAL.setting";
    String name = "[api job] " + media_url + " " + setting_path;
    int prio = 500;
    Hashtable<String, String> metadata = new Hashtable<String, String>();
    metadata.put("one", "1");
    Integer newJobID = (Integer) client.invoke("engine.submitJob", new Object[]{media_url, setting_path, name, prio, metadata});
    System.out.println("submitted job id: " + newJobID);

    // get initial status for the newly submitted job
    XmlRpcStruct status = (XmlRpcStruct) client.invoke("engine.getJobForID", new Object[]{newJobID});
    System.out.println("status: " + status);

    return newJobID;
  }

  /**
    * Return progress for a specified job id
    */
  public int getProgressForJobID(int aJobID) throws MalformedURLException, XmlRpcException, XmlRpcFault {
    // get progress for a job
    XmlRpcStruct status = (XmlRpcStruct) client.invoke("engine.getJobForID", new Object[]{aJobID});

    int state = status.getStruct("currentStatus").getInteger("state");
    if (state == 3 || state == 5) {
      //Stopped, Failed jobs
      return -1;
    }
    if (state == 4) {
      //Finished jobs
      return 100;
    }
    int progress = status.getStruct("currentStatus").getInteger("progress");
    return progress;
  }
}
